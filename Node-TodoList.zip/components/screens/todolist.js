const inquirer = require('inquirer')
const Operations = require("./config/events")

inquirer.prompt(
    {
        message: "What do you want to do?",
        type: "list",
        name: "question1",
        choices: ["Create", "Read", "Update", "Delete"]
    }
)
    .then(function (answers) {
        if (answers.question1 == "Create") {
            Operations.Create();
        }
        else if (answers.question1 == "Read") {
            Operations.Read();
        }
        else if (answers.question1 == "Update") {
            Operations.Update();
        }
        else if (answers.question1 == "Delete") {
            Operations.Delete();
        }
    }
);