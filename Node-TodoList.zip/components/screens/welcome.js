const figlet = require("figlet");
const clear = require('clear');
var fs = require("fs");
 
figlet('Todo List', function(err, data) {
    if (err) {
        console.log('Something went wrong...');
        console.dir(err);
        return;
    }
    console.log(data)
    console.log("welcome to ToDo List!")
    
});
let todolist = require("./todolist");

