const inquirer = require('inquirer')
var fs = require("fs");
const Operation = require('./operation')

function Create() {
    inquirer.prompt({
        message: "Name: ",
        type: "text",
        name: "name"
    }).then(function (answer1) {
        inquirer.prompt({
            message: "Description: ",
            type: "text",
            name: "description"
        }).then(function (answer2) {
            inquirer.prompt({
                message: "Status: ",
                type: "list",
                name: "status",
                choices: ["onHold", "inProcess", "Complete"]
            }).then(function (answer3) {
                var obj = {
                    name: answer1.name,
                    description: answer2.description,
                    status: answer3.status[0]
                }
                Operation.writeNew(obj)
            })  
            
        })
    })
}
function Read(){
    var opt = Operation.readAll()
    inquirer.prompt({
        message: "Name: ",
        type: "list",
        name: "name",
        choices: opt
    }).then(function (answer1) {
        Operation.readSingle(answer1.name)
    })
}
function Update(){
    var opt = Operation.readAll()
    inquirer.prompt({
        message: "Name: ",
        type: "list",
        name: "name",
        choices: opt
    }).then(function (answer1) {
        inquirer.prompt({
            message: "Description: ",
            type: "text",
            name: "description"
        }).then(function (answer2) {
            inquirer.prompt({
                message: "Status: ",
                type: "list",
                name: "status",
                choices: ["onHold", "inProcess", "Complete"]
            }).then(function (answer3) {
                var obj = {
                    name: answer1.name,
                    description: answer2.description,
                    status: answer3.status[0]
                }
                Operation.update(obj)
                //console.log(obj)
            })  
            
        })
    })
}
function Delete(){
    var opt = Operation.readAll()
    inquirer.prompt({
        message: "Name: ",
        type: "list",
        name: "name",
        choices: opt
    }).then(function (answer1) {
        Operation.deleteSingle(answer1.name)
    })
}

module.exports = {
    Create,
    Read,
    Update,
    Delete
}